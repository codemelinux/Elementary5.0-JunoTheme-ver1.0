## My plank themes
place folders into `.local/share/plank/themes`

#### Anti-Shade
![anti-shade](https://raw.githubusercontent.com/KenHarkey/plank-themes/master/screenshots/anti-shade.png)

#### Paperterial
![paperterial](https://raw.githubusercontent.com/KenHarkey/plank-themes/master/screenshots/paperterial.png)

#### Shade
![shade](https://raw.githubusercontent.com/KenHarkey/plank-themes/master/screenshots/shade.png)
